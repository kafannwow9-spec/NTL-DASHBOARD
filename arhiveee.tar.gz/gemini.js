require('./utils/loadEnv.js');
const axios = require('axios');

const GEMINI_API_KEY = process.env.GEMINI_API_KEY_2 || process.env.GEMINI_API_KEY || "";
const GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite:generateContent";

const SYSTEM_PROMPT_RULES = `أنت "NTL AI"، خوي وعضو حقيقي ومساعد ذكي في سيرفر ديسكورد. تتكلم بلغة عامية عفوية، خفيفة، وودودة (خليجي أو شامي بسيط بدون أي تشكيل أو لغة فصحى معقدة).

قواعدك:
1. الروح الحلوة والسرعة: سولف، اضحك، وكن خفيف دم وفاعل مع الشباب. لا تكن جاداً أو هادئاً زيادة عن اللزوم. رد بسرعة وبأقل قدر من الحشو (سطر أو سطرين).
2. ممنوع النسخ أو التقليد (ليس ببغاء): لا تكرر شتم المستخدم بنفس ألفاظه أبداً. إذا استفزك أحد، رد عليه برد ذكي، ساخر، وبكاريزما خفيفة تضحك الشباب.
3. تفاصيل المفاتيح: 
   - إذا طلب المفتاح، قوله بسلاسة: (جيب رابط مفتاحك من روبلوكس، حطه بجوجل وانتظر 5 ثواني واضغط continue، سجل دخول وانسخ الرابط وارسله هنا أو بروم المفاتيح <#1521436136420020275> وأنا أخوك أفكه لك).
   - إذا ما ضبطت الطريقة الأولى، قوله: (ولا يهمك، انسخ رابط موقع المهام من الثلاث نقاط أو شريط البحث وارسله هنا وأضبطك).
4. حماية المنشن: ممنوع منعاً باتاً كتابة أي منشن مثل @everyone أو @here أو ربط الرمز @ بأي رتبة.`;

function cleanOutput(text) {
    if (!text || typeof text !== 'string') return '';
    let t = text;
    
    // إزالة وسوم التفكير
    t = t.replace(/<think>[\s\S]*?<\/think>/gi, '');
    t = t.replace(/^(?:We cannot call tools|Thinking Process|The user wants|Let's think|The user asked|Instruction:)[\s\S]*?(?:Let's deliver\.?|Let's respond\.?|\n\n)/i, '');
    
    // 🛡️ حماية أمنية برمجية لمنع منشن @everyone أو @here نهائياً
    t = t.replace(/@\s*(everyone|here|الجميع)/gi, 'at-$1');
    t = t.replace(/@(everyone|here)/gi, 'at-$1');

    return t.trim();
}

async function askAI(prompt) {
    let contents = [];
    let systemInstructionText = SYSTEM_PROMPT_RULES;

    if (Array.isArray(prompt)) {
        for (const m of prompt) {
            if (m.role === 'system') {
                systemInstructionText = m.content;
            } else if (m.role === 'user') {
                contents.push({ role: 'user', parts: [{ text: m.content }] });
            } else if (m.role === 'assistant') {
                contents.push({ role: 'model', parts: [{ text: m.content }] });
            }
        }
    } else {
        contents.push({ 
            role: 'user', 
            parts: [{ text: typeof prompt === 'string' ? prompt : JSON.stringify(prompt) }] 
        });
    }

    const requestBody = {
        system_instruction: {
            parts: [{ text: systemInstructionText }]
        },
        contents: contents,
        generationConfig: {
            temperature: 0.6,     // حرارة معتدلة ليعطي حيوية ومزح وطبيعية بدون جمود
            maxOutputTokens: 100  // ردود سريعة ومختصرة
        }
    };

    try {
        const response = await axios.post(
            GEMINI_URL,
            requestBody,
            {
                headers: {
                    "X-goog-api-key": GEMINI_API_KEY,
                    "Content-Type": "application/json"
                },
                timeout: 10000
            }
        );

        const data = response.data;
        if (data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts) {
            const rawText = data.candidates[0].content.parts[0].text || "";
            const cleaned = cleanOutput(rawText);
            if (cleaned && cleaned.length > 0) {
                return cleaned;
            }
        }
    } catch (error) {
        console.warn(`[Gemini API error]:`, error.response?.data?.error?.message || error.message);
    }

    return "";
}

module.exports = {
    askAI,
    SYSTEM_PROMPT_RULES,
    GEMINI_API_KEY
};
